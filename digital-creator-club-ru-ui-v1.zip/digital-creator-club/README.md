# Digital Creator Club WordPress Plugin

MVP plugin for a club site that provides:

- shortcode output for the clipart idea generator
- member-only access
- monthly credits per user
- server-side prompt generation
- admin settings for quota and limits

## Shortcode

Use:

```text
[dcc_tool_router]
```

The tools page should use `dcc_tool_router`. Individual tool pages can also use direct shortcodes.

Optional direct shortcode for the current generator:

```text
[dcc_clipart_generator]
```

Second tool:

```text
[dcc_bundle_planner]
```

## Default behavior

- each generated item costs 1 credit
- new users start with the monthly default quota
- quota resets on a new month
- the tool only runs for logged-in users when login is required
- the tool hub lists all available and planned tools

## Next step

Wire the plugin into your WordPress club page and connect it to your membership system if you already have one.
