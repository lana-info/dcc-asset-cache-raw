<?php
/**
 * Plugin Name: Digital Creator Club
 * Description: Club tools for creating clipart ideas and digital product prompts with member quotas.
 * Version: 0.1.6
 * Author: OpenAI
 */

if (!defined('ABSPATH')) {
    exit;
}

define('DCC_VERSION', '0.1.6');
define('DCC_PATH', plugin_dir_path(__FILE__));
define('DCC_URL', plugin_dir_url(__FILE__));

function dcc_tools_registry() {
    return array(
        'clipart-generator' => array(
            'title' => 'Генератор идей клипарта',
            'description' => 'Генерация структурированных идей и промтов для наборов цифровых товаров.',
            'shortcode' => '[dcc_clipart_generator]',
            'status' => 'Доступно',
            'available' => true,
        ),
        'bundle-planner' => array(
            'title' => 'Планировщик набора',
            'description' => 'Планирование набора по объектам, элементам и сценам.',
            'shortcode' => '[dcc_bundle_planner]',
            'status' => 'Доступно',
            'available' => true,
        ),
        'seo-helper' => array(
            'title' => 'Etsy SEO помощник',
            'description' => 'Черновики названий, тегов и описаний для цифровых товаров.',
            'shortcode' => '',
            'status' => 'Скоро',
            'available' => false,
        ),
    );
}

function dcc_default_settings() {
    return array(
        'monthly_credits' => 100,
        'credits_per_item' => 1,
        'max_groups' => 8,
        'max_items_per_group' => 12,
        'require_login' => 1,
    );
}

function dcc_get_settings() {
    return wp_parse_args(get_option('dcc_settings', array()), dcc_default_settings());
}

function dcc_activate() {
    if (!get_option('dcc_settings')) {
        add_option('dcc_settings', dcc_default_settings());
    }
}
register_activation_hook(__FILE__, 'dcc_activate');

function dcc_current_month() {
    return current_time('Y-m');
}

function dcc_ensure_user_quota($user_id) {
    $settings = dcc_get_settings();
    $window = get_user_meta($user_id, 'dcc_quota_window', true);
    $limit = (int) $settings['monthly_credits'];
    $remaining = get_user_meta($user_id, 'dcc_credits_remaining', true);

    if ($window !== dcc_current_month() || $remaining === '') {
        update_user_meta($user_id, 'dcc_quota_window', dcc_current_month());
        update_user_meta($user_id, 'dcc_credits_limit', $limit);
        update_user_meta($user_id, 'dcc_credits_remaining', $limit);
    }

    return array(
        'limit' => (int) get_user_meta($user_id, 'dcc_credits_limit', true),
        'remaining' => (int) get_user_meta($user_id, 'dcc_credits_remaining', true),
        'window' => get_user_meta($user_id, 'dcc_quota_window', true),
    );
}

function dcc_register_assets() {
    wp_register_style('dcc-frontend', DCC_URL . 'assets/frontend.css', array(), DCC_VERSION);
    wp_register_script('dcc-frontend', DCC_URL . 'assets/frontend.js', array(), DCC_VERSION, true);
}
add_action('wp_enqueue_scripts', 'dcc_register_assets');

function dcc_register_query_vars($vars) {
    $vars[] = 'dcc_tool';
    return $vars;
}
add_filter('query_vars', 'dcc_register_query_vars');

function dcc_admin_menu() {
    add_options_page(
        'Digital Creator Club',
        'Digital Creator Club',
        'manage_options',
        'dcc-settings',
        'dcc_render_settings_page'
    );
}
add_action('admin_menu', 'dcc_admin_menu');

function dcc_register_settings() {
    register_setting('dcc_settings_group', 'dcc_settings', 'dcc_sanitize_settings');

    add_settings_section(
        'dcc_main',
        'Club limits',
        function () {
            echo '<p>Default quota and generator limits for new members.</p>';
        },
        'dcc-settings'
    );

    $fields = array(
        'monthly_credits' => 'Monthly credits',
        'credits_per_item' => 'Credits per generated item',
        'max_groups' => 'Max groups per pack',
        'max_items_per_group' => 'Max items per group',
        'require_login' => 'Require login',
    );

    foreach ($fields as $key => $label) {
        add_settings_field(
            'dcc_' . $key,
            $label,
            'dcc_render_setting_field',
            'dcc-settings',
            'dcc_main',
            array('key' => $key)
        );
    }
}
add_action('admin_init', 'dcc_register_settings');

function dcc_sanitize_settings($input) {
    $defaults = dcc_default_settings();

    return array(
        'monthly_credits' => max(1, (int) ($input['monthly_credits'] ?? $defaults['monthly_credits'])),
        'credits_per_item' => max(1, (int) ($input['credits_per_item'] ?? $defaults['credits_per_item'])),
        'max_groups' => max(1, (int) ($input['max_groups'] ?? $defaults['max_groups'])),
        'max_items_per_group' => max(1, (int) ($input['max_items_per_group'] ?? $defaults['max_items_per_group'])),
        'require_login' => !empty($input['require_login']) ? 1 : 0,
    );
}

function dcc_render_setting_field($args) {
    $settings = dcc_get_settings();
    $key = $args['key'];
    $value = $settings[$key] ?? '';

    if ($key === 'require_login') {
        printf(
            '<label><input type="checkbox" name="dcc_settings[%1$s]" value="1" %2$s> Restrict tool access to logged-in users</label>',
            esc_attr($key),
            checked(1, (int) $value, false)
        );
        return;
    }

    printf(
        '<input type="number" min="1" class="regular-text" name="dcc_settings[%1$s]" value="%2$s">',
        esc_attr($key),
        esc_attr($value)
    );
}

function dcc_render_settings_page() {
    ?>
    <div class="wrap">
        <h1>Digital Creator Club</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('dcc_settings_group');
            do_settings_sections('dcc-settings');
            submit_button();
            ?>
        </form>
        <p>Use shortcode: <code>[dcc_clipart_generator]</code></p>
    </div>
    <?php
}

function dcc_normalize_groups($groups) {
    $normalized = array();

    if (!is_array($groups)) {
        return $normalized;
    }

    foreach ($groups as $group) {
        $name = sanitize_text_field($group['name'] ?? '');
        $count = max(1, (int) ($group['count'] ?? 1));

        if ($name === '') {
            continue;
        }

        $normalized[] = array(
            'name' => $name,
            'count' => $count,
        );
    }

    return $normalized;
}

function dcc_motif_pool() {
    return array(
        'mushroom', 'flower', 'star', 'rabbit', 'cloud', 'bow', 'berry', 'leaf',
        'moon', 'bird', 'acorn', 'teacup', 'pumpkin', 'snail', 'butterfly'
    );
}

function dcc_default_group_rows() {
    return array(
        array('name' => 'object', 'count' => 3),
        array('name' => 'decorative elements', 'count' => 3),
        array('name' => 'borders / frames', 'count' => 3),
    );
}

function dcc_adjective_pool() {
    return array(
        'tiny', 'rounded', 'gentle', 'cozy', 'soft', 'delicate', 'playful', 'minimal',
        'sweet', 'whimsical', 'calm', 'friendly', 'dreamy', 'light', 'storybook'
    );
}

function dcc_palette_options() {
    return array(
        'auto' => array(
            'label' => 'Нейросеть выберет',
            'description' => 'Модель сама подберет лучшую палитру под тему.',
            'swatches' => array('#f6efe8', '#e7d4be', '#d3b3a5', '#b98a7d'),
        ),
        'match_images' => array(
            'label' => 'Под цвета моих изображений',
            'description' => 'Ориентироваться на загруженные референсы.',
            'swatches' => array('#e8f2ef', '#d2e7dc', '#a9cdbd', '#7fa891'),
        ),
        'none' => array(
            'label' => 'Без палитры',
            'description' => 'Не фиксировать цвета в промте.',
            'swatches' => array('#f4f1ed', '#e7e0d8', '#d0c7bc', '#b9aea0'),
        ),
        'warm' => array(
            'label' => 'Теплая нейтральная',
            'description' => 'Мягкие бежевые и пудровые тона.',
            'swatches' => array('#f4e7d8', '#ead7c1', '#e4c0b6', '#b98f73'),
        ),
        'spring' => array(
            'label' => 'Весенняя свежесть',
            'description' => 'Светлые зеленые и воздушные пастели.',
            'swatches' => array('#dfe9d5', '#f6e8a6', '#c7dff0', '#f8d8cc'),
        ),
        'storybook' => array(
            'label' => 'Сказочная',
            'description' => 'Пыльная роза и карамель с винтажным настроением.',
            'swatches' => array('#e8c0bf', '#d8b08c', '#f4eadc', '#efc9a1'),
        ),
        'coastal' => array(
            'label' => 'Морское спокойствие',
            'description' => 'Мята, песок и ракушечный розовый.',
            'swatches' => array('#cce9df', '#f2e1b7', '#cfe0ea', '#f4d6d9'),
        ),
        'earthy' => array(
            'label' => 'Земляная',
            'description' => 'Олива, глина, овес и терракота.',
            'swatches' => array('#a8b08d', '#d3b28c', '#e7d9c4', '#c9835b'),
        ),
        'candy' => array(
            'label' => 'Конфетная пастель',
            'description' => 'Клубничный, мятный, сиреневый и кремовый.',
            'swatches' => array('#f7c2cb', '#cdebd6', '#d8cbf6', '#fff0c9'),
        ),
        'vintage' => array(
            'label' => 'Винтажная бумага',
            'description' => 'Приглушенный пергамент, розовое дерево и блеклый синий.',
            'swatches' => array('#eadfc9', '#c9968b', '#9cb8cf', '#b9a68a'),
        ),
        'custom' => array(
            'label' => 'Свои цвета',
            'description' => 'Введите свои названия цветов или hex-коды.',
            'swatches' => array('#efe7df', '#d9d1c7', '#bfae9d', '#9e8c7c'),
        ),
    );
}

function dcc_palette_summary($palette_key, $custom_colors = '') {
    $options = dcc_palette_options();

    if ($palette_key === 'custom') {
        $custom_colors = trim(sanitize_textarea_field($custom_colors));

        if ($custom_colors !== '') {
            return 'custom colors: ' . $custom_colors;
        }

        return 'custom colors chosen by the user';
    }

    if ($palette_key === 'auto' || !isset($options[$palette_key])) {
        return 'palette chosen by AI';
    }

    if ($palette_key === 'match_images') {
        return 'palette matched to inspiration images';
    }

    if ($palette_key === 'none') {
        return 'no palette guidance';
    }

    $swatches = implode(', ', $options[$palette_key]['swatches']);

    return $options[$palette_key]['label'] . ' palette: ' . $swatches;
}

function dcc_generate_groups($input) {
    $theme = sanitize_text_field($input['theme'] ?? 'untitled clipart pack');
    $template = sanitize_textarea_field($input['template'] ?? '');
    $rules = sanitize_textarea_field($input['rules'] ?? '');
    $mode = in_array(($input['mode'] ?? 'prompts'), array('ideas', 'prompts'), true) ? $input['mode'] : 'prompts';
    $palette_key = sanitize_text_field($input['palette'] ?? 'auto');
    $custom_colors = sanitize_text_field($input['custom_colors'] ?? '');
    $palette = dcc_palette_summary($palette_key, $custom_colors);
    $groups = dcc_normalize_groups($input['groups'] ?? array());

    $adjectives = dcc_adjective_pool();
    $motifs = dcc_motif_pool();
    $results = array();

    foreach ($groups as $group_index => $group) {
        $items = array();
        $group_name = ucfirst(trim($group['name']));

        for ($i = 0; $i < $group['count']; $i++) {
            $seed = abs(crc32($theme . '|' . $group['name'] . '|' . $i));
            $adjective = $adjectives[$seed % count($adjectives)];
            $motif = $motifs[($seed + $group_index) % count($motifs)];
            $title = sprintf('%s %s %d', ucfirst($adjective), rtrim($group_name, 's'), $i + 1);

            if ($mode === 'ideas') {
                $prompt = sprintf(
                    '%s idea for %s with %s %s and %s',
                    $theme,
                    strtolower($group_name),
                    $adjective,
                    $motif,
                    $palette
                );
            } else {
                $prompt = trim(
                    implode(', ', array_filter(array(
                        $template,
                        sprintf('%s for a %s', $adjective . ' ' . $motif, $theme),
                        'color palette: ' . $palette,
                        $rules !== '' ? 'rules: ' . $rules : '',
                    )))
                );
            }

            $items[] = array(
                'title' => $title,
                'prompt' => $prompt,
            );
        }

        $results[] = array(
            'name' => $group_name,
            'items' => $items,
        );
    }

    return $results;
}

function dcc_generate_bundle_plan($input) {
    $theme = sanitize_text_field($input['theme'] ?? 'untitled bundle');
    $audience = sanitize_text_field($input['audience'] ?? 'club members');
    $bundle_type = sanitize_text_field($input['bundle_type'] ?? 'clipart bundle');
    $item_count = max(3, min(12, (int) ($input['item_count'] ?? 6)));
    $style = sanitize_text_field($input['style'] ?? 'cute watercolor');
    $must_include = sanitize_textarea_field($input['must_include'] ?? '');

    $motifs = dcc_motif_pool();
    $adjectives = dcc_adjective_pool();
    $sections = array();
    $bundle_items = array();

    for ($i = 0; $i < $item_count; $i++) {
        $seed = abs(crc32($theme . '|' . $bundle_type . '|' . $i));
        $motif = $motifs[$seed % count($motifs)];
        $adjective = $adjectives[($seed + 3) % count($adjectives)];
        $bundle_items[] = sprintf('%s %s %s', ucfirst($adjective), $motif, $i + 1);
    }

    $sections[] = array(
        'title' => 'Theme',
        'body' => $theme,
    );
    $sections[] = array(
        'title' => 'Audience',
        'body' => $audience,
    );
    $sections[] = array(
        'title' => 'Style',
        'body' => $style,
    );
    $sections[] = array(
        'title' => 'Bundle items',
        'body' => implode(', ', $bundle_items),
    );

    if ($must_include !== '') {
        $sections[] = array(
            'title' => 'Must include',
            'body' => $must_include,
        );
    }

    return array(
        'title' => sprintf('%s for %s', $bundle_type, $theme),
        'bundle_type' => $bundle_type,
        'sections' => $sections,
        'items' => $bundle_items,
        'item_count' => $item_count,
    );
}

function dcc_tools_base_url() {
    return remove_query_arg('dcc_tool', get_permalink());
}

function dcc_tool_url($tool_key) {
    return add_query_arg('dcc_tool', $tool_key, dcc_tools_base_url());
}

function dcc_render_tools_hub() {
    $tools = dcc_tools_registry();

    ob_start();
    ?>
    <div class="dcc-hub">
        <div class="dcc-hub__header">
            <p class="dcc-kicker">Club tools</p>
            <h2>Available tools</h2>
            <p class="dcc-muted">Choose a tool. More modules can be added later without changing the page structure.</p>
        </div>
        <div class="dcc-hub__grid">
            <?php foreach ($tools as $tool_key => $tool) : ?>
                <article class="dcc-hub-card <?php echo $tool['available'] ? 'is-available' : 'is-soon'; ?>">
                    <div class="dcc-hub-card__top">
                        <span class="dcc-badge"><?php echo esc_html($tool['status']); ?></span>
                    </div>
                    <h3><?php echo esc_html($tool['title']); ?></h3>
                    <p><?php echo esc_html($tool['description']); ?></p>
                    <?php if ($tool['available']) : ?>
                        <a class="dcc-tool-link" href="<?php echo esc_url(dcc_tool_url($tool_key)); ?>">Open tool</a>
                    <?php else : ?>
                        <span class="dcc-tool-link is-disabled">Coming soon</span>
                    <?php endif; ?>
                </article>
            <?php endforeach; ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

function dcc_shortcode_tools_hub() {
    return dcc_render_tools_hub();
}
add_shortcode('dcc_tools_hub', 'dcc_shortcode_tools_hub');

function dcc_render_tool_router() {
    $tool_key = sanitize_key(get_query_var('dcc_tool'));
    $tools = dcc_tools_registry();

    if ($tool_key && isset($tools[$tool_key])) {
        if ($tool_key === 'clipart-generator') {
            return dcc_shortcode_clipart_generator();
        }
        if ($tool_key === 'bundle-planner') {
            return dcc_shortcode_bundle_planner();
        }
    }

    return dcc_render_tools_hub();
}

function dcc_shortcode_tool_router() {
    return dcc_render_tool_router();
}
add_shortcode('dcc_tool_router', 'dcc_shortcode_tool_router');

function dcc_total_items($groups) {
    $total = 0;

    foreach ($groups as $group) {
        $total += max(1, (int) ($group['count'] ?? 1));
    }

    return $total;
}

function dcc_shortcode_clipart_generator() {
    $settings = dcc_get_settings();

    if ((int) $settings['require_login'] === 1 && !is_user_logged_in()) {
        return '<div class="dcc-locked">Инструмент доступен только авторизованным участникам клуба.</div>';
    }

    if (!is_user_logged_in()) {
        return '<div class="dcc-locked">Войдите в аккаунт, чтобы использовать инструмент.</div>';
    }

    $user_id = get_current_user_id();
    $quota = dcc_ensure_user_quota($user_id);
    $tools_url = dcc_tools_base_url();

    wp_enqueue_style('dcc-frontend');
    wp_enqueue_script('dcc-frontend');
    wp_localize_script(
        'dcc-frontend',
        'DCC_TOOL',
        array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('dcc_generate_clipart'),
            'creditsPerItem' => (int) $settings['credits_per_item'],
            'maxGroups' => (int) $settings['max_groups'],
            'maxItemsPerGroup' => (int) $settings['max_items_per_group'],
            'remainingCredits' => (int) $quota['remaining'],
            'monthlyCredits' => (int) $quota['limit'],
        )
    );

    ob_start();
    ?>
    <div class="dcc-muse-page">
        <section class="dcc-muse-hero">
            <div class="dcc-muse-hero__text">
                <p class="dcc-kicker">Моя Мастерская</p>
                <h2>Генератор идей клипарта</h2>
                <p class="dcc-muted">Создавайте идеи и готовые промты в структурированных группах. Сохраняйте единый стиль и ускоряйте выпуск наборов.</p>
                <p class="dcc-backlink"><a href="<?php echo esc_url($tools_url); ?>">&larr; К списку инструментов</a></p>
            </div>
            <div class="dcc-muse-hero__visual" aria-hidden="true">✨</div>
        </section>

        <div class="dcc-tool" data-dcc-tool>
            <div class="dcc-tool__hero">
                <div class="dcc-quota">
                    <strong data-dcc-remaining><?php echo esc_html((string) $quota['remaining']); ?></strong>
                    <span>из <?php echo esc_html((string) $quota['limit']); ?> кредитов осталось в этом месяце</span>
                </div>
            </div>

            <form class="dcc-form" data-dcc-form>
            <div class="dcc-step-head">
                <span class="dcc-step-badge">1</span>
                <h3>Соберем вашу идею</h3>
            </div>
            <div class="dcc-row" hidden>
                <label class="dcc-field">
                    <span>Режим</span>
                    <select name="mode">
                        <option value="prompts" selected>Готовые промты</option>
                        <option value="ideas">Только идеи</option>
                    </select>
                </label>
            </div>

            <label class="dcc-field">
                <span>Тема</span>
                <input type="text" name="theme" value="cozy autumn woodland nursery clipart" />
            </label>

            <label class="dcc-field">
                <span>Шаблон промта</span>
                <textarea name="template" rows="4">cute watercolor hand-drawn clipart, isolated on white background, soft pastel colors, clean pencil line</textarea>
            </label>

            <div class="dcc-groups" data-dcc-groups>
                <div class="dcc-group-head">
                    <span>Группы</span>
                    <span>Количество</span>
                </div>

                <?php foreach (dcc_default_group_rows() as $default_group) : ?>
                    <div class="dcc-group-row" data-dcc-group>
                        <input type="text" name="group_name[]" value="<?php echo esc_attr($default_group['name']); ?>" placeholder="например: животные" />
                        <input type="number" min="1" max="<?php echo esc_attr((string) $settings['max_items_per_group']); ?>" name="group_count[]" value="<?php echo esc_attr((string) $default_group['count']); ?>" />
                        <button type="button" class="dcc-icon-button" data-dcc-remove-group aria-label="Удалить группу">x</button>
                    </div>
                <?php endforeach; ?>
            </div>

            <button type="button" class="dcc-secondary" data-dcc-add-group>Добавить группу</button>

            <label class="dcc-field">
                <span>Специальные правила</span>
                <textarea name="rules" rows="3">full body, no text, no background, consistent palette, simple shapes</textarea>
            </label>

            <div class="dcc-field">
                <div class="dcc-step-head">
                    <span class="dcc-step-badge">2</span>
                    <h3>Референсы для набора (необязательно)</h3>
                </div>
                <span>Изображения-вдохновение</span>
                <p class="dcc-hint">До 4 изображений для вдохновения по идеям, мотивам и палитре. Мы не копируем чужие работы.</p>
                <div class="dcc-image-slots" data-dcc-image-slots>
                    <?php for ($i = 1; $i <= 4; $i++) : ?>
                        <label class="dcc-image-slot" data-dcc-image-slot>
                            <input type="file" name="inspiration_image_<?php echo esc_attr((string) $i); ?>" accept="image/*" />
                            <span class="dcc-image-slot__inner">
                                <span class="dcc-image-slot__plus">+</span>
                                <span class="dcc-image-slot__text">Нажмите или перетащите</span>
                            </span>
                        </label>
                    <?php endfor; ?>
                </div>
            </div>

            <div class="dcc-field">
                <div class="dcc-step-head">
                    <span class="dcc-step-badge">3</span>
                    <h3>Цветовая палитра</h3>
                </div>
                <span>Палитра</span>
                <div class="dcc-palette-grid">
                    <div class="dcc-palette-tabs" role="group" aria-label="Palette modes">
                        <?php foreach (array('auto', 'custom', 'match_images', 'none') as $palette_key) : ?>
                            <?php $palette_option = dcc_palette_options()[$palette_key]; ?>
                            <label class="dcc-palette-tab <?php echo $palette_key === 'auto' ? 'is-primary' : ''; ?>">
                                <input type="radio" name="palette" value="<?php echo esc_attr($palette_key); ?>" <?php checked($palette_key, 'auto'); ?> />
                                <span class="dcc-palette-tab__label"><?php echo esc_html($palette_option['label']); ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>

                    <div class="dcc-palette-variants" aria-label="Preset palettes">
                        <?php foreach (array('warm', 'spring', 'storybook', 'coastal', 'earthy', 'candy', 'vintage') as $palette_key) : ?>
                            <?php $palette_option = dcc_palette_options()[$palette_key]; ?>
                            <label class="dcc-palette-option">
                                <input type="radio" name="palette" value="<?php echo esc_attr($palette_key); ?>" />
                                <span class="dcc-palette-option__card">
                                    <span class="dcc-palette-swatches" aria-hidden="true">
                                        <?php foreach ($palette_option['swatches'] as $index => $swatch) : ?>
                                            <span class="dcc-palette-swatch" style="<?php echo esc_attr('--dcc-swatch: ' . $swatch . '; --dcc-swatch-delay: ' . ($index * 28) . 'ms;'); ?>"></span>
                                        <?php endforeach; ?>
                                    </span>
                                </span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <label class="dcc-field" data-dcc-custom-palette hidden>
                <span>Свои цвета</span>
                <textarea name="custom_colors" rows="2" placeholder="например: #E7D7C9, пудрово-розовый, шалфейный"></textarea>
            </label>

            <div class="dcc-actions">
                <button type="submit" class="dcc-primary">Сгенерировать</button>
                <span class="dcc-cost">Стоимость: <strong data-dcc-cost>0</strong> кредитов</span>
            </div>
        </form>

            <div class="dcc-notice" data-dcc-notice hidden></div>
            <div class="dcc-results" data-dcc-results></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('dcc_clipart_generator', 'dcc_shortcode_clipart_generator');

function dcc_shortcode_bundle_planner() {
    $settings = dcc_get_settings();

    if ((int) $settings['require_login'] === 1 && !is_user_logged_in()) {
        return '<div class="dcc-locked">This tool is available to logged-in club members only.</div>';
    }

    if (!is_user_logged_in()) {
        return '<div class="dcc-locked">Please log in to use this tool.</div>';
    }

    $user_id = get_current_user_id();
    $quota = dcc_ensure_user_quota($user_id);
    $tools_url = dcc_tools_base_url();
    $form_values = array(
        'theme' => 'cozy autumn woodland nursery',
        'audience' => 'Etsy buyers',
        'bundle_type' => 'clipart bundle',
        'item_count' => 6,
        'style' => 'cute watercolor, soft pastel, isolated on white',
        'must_include' => 'consistent palette, no text, no background',
    );

    ob_start();
    ?>
    <div class="dcc-bundle">
        <div class="dcc-tool__hero">
            <div>
                <p class="dcc-kicker">Club tool</p>
                <h2>Bundle Planner</h2>
                <p class="dcc-muted">Plan the structure of a product bundle before you generate prompts or assets. Great for pack outlines and product planning.</p>
                <p class="dcc-backlink"><a href="<?php echo esc_url($tools_url); ?>">&larr; Back to tools</a></p>
            </div>
            <div class="dcc-quota">
                <strong><?php echo esc_html((string) $quota['remaining']); ?></strong>
                <span>of <?php echo esc_html((string) $quota['limit']); ?> credits left this month</span>
            </div>
        </div>
        <div class="dcc-results">
            <section class="dcc-result-group">
                <div class="dcc-result-group__head">
                    <h3>Example bundle plan</h3>
                    <span class="dcc-badge">Preview</span>
                </div>
                <article class="dcc-result-item">
                    <div class="dcc-result-item__head">
                        <strong>Theme</strong>
                    </div>
                    <p class="dcc-result-box"><?php echo esc_html($form_values['theme']); ?></p>
                </article>
                <article class="dcc-result-item">
                    <div class="dcc-result-item__head">
                        <strong>Audience</strong>
                    </div>
                    <p class="dcc-result-box"><?php echo esc_html($form_values['audience']); ?></p>
                </article>
                <article class="dcc-result-item">
                    <div class="dcc-result-item__head">
                        <strong>Style</strong>
                    </div>
                    <p class="dcc-result-box"><?php echo esc_html($form_values['style']); ?></p>
                </article>
            </section>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('dcc_bundle_planner', 'dcc_shortcode_bundle_planner');

function dcc_ajax_generate_clipart() {
    check_ajax_referer('dcc_generate_clipart', 'nonce');

    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'Войдите в аккаунт, чтобы выполнить генерацию.'), 401);
    }

    $settings = dcc_get_settings();
    $user_id = get_current_user_id();
    $quota = dcc_ensure_user_quota($user_id);

    $payload = array(
        'mode' => sanitize_text_field($_POST['mode'] ?? 'prompts'),
        'theme' => sanitize_text_field($_POST['theme'] ?? ''),
        'template' => sanitize_textarea_field($_POST['template'] ?? ''),
        'rules' => sanitize_textarea_field($_POST['rules'] ?? ''),
        'palette' => sanitize_text_field($_POST['palette'] ?? 'auto'),
        'custom_colors' => sanitize_textarea_field($_POST['custom_colors'] ?? ''),
        'groups' => array(),
    );

    $group_names = isset($_POST['group_name']) ? (array) $_POST['group_name'] : array();
    $group_counts = isset($_POST['group_count']) ? (array) $_POST['group_count'] : array();

    foreach ($group_names as $index => $name) {
        $payload['groups'][] = array(
            'name' => sanitize_text_field($name),
            'count' => isset($group_counts[$index]) ? (int) $group_counts[$index] : 1,
        );
    }

    $payload['groups'] = dcc_normalize_groups($payload['groups']);

    if (empty($payload['groups'])) {
        wp_send_json_error(array('message' => 'Добавьте хотя бы одну группу.'), 400);
    }

    if (count($payload['groups']) > (int) $settings['max_groups']) {
        wp_send_json_error(array('message' => 'Слишком много групп для одного набора.'), 400);
    }

    foreach ($payload['groups'] as $group) {
        if ($group['count'] > (int) $settings['max_items_per_group']) {
            wp_send_json_error(array('message' => 'В одной из групп превышен лимит количества элементов.'), 400);
        }
    }

    $items_requested = dcc_total_items($payload['groups']);
    $cost = $items_requested * (int) $settings['credits_per_item'];

    if ($cost > $quota['remaining']) {
        wp_send_json_error(array(
            'message' => 'Недостаточно кредитов для этой генерации.',
            'remaining' => $quota['remaining'],
            'cost' => $cost,
        ), 402);
    }

    $results = dcc_generate_groups($payload);
    $remaining = max(0, $quota['remaining'] - $cost);
    update_user_meta($user_id, 'dcc_credits_remaining', $remaining);
    update_user_meta($user_id, 'dcc_quota_window', dcc_current_month());

    wp_send_json_success(array(
        'results' => $results,
        'cost' => $cost,
        'remaining' => $remaining,
        'limit' => $quota['limit'],
        'generated_at' => current_time('mysql'),
    ));
}
add_action('wp_ajax_dcc_generate_clipart', 'dcc_ajax_generate_clipart');
