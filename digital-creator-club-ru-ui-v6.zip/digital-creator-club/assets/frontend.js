(function () {
  function escapeHtml(text) {
    return text
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#39;");
  }

  function escapeAttr(text) {
    return escapeHtml(String(text)).replaceAll("\n", "&#10;").replaceAll("\r", "");
  }

  function buildResultHtml(results) {
    return results
      .map(function (group) {
        var items = group.items
          .map(function (item) {
            return (
              '<article class="dcc-result-item">' +
              '<div class="dcc-result-item__head">' +
              "<strong>* " +
              escapeHtml(item.title) +
              "</strong>" +
              '<button type="button" class="dcc-copy" data-dcc-copy="' +
              escapeAttr(item.prompt) +
              '">Копировать</button>' +
              "</div>" +
              '<p class="dcc-result-box">' +
              escapeHtml(item.prompt) +
              "</p>" +
              "</article>"
            );
          })
          .join("");

        return (
          '<section class="dcc-result-group">' +
          '<div class="dcc-result-group__head">' +
          "<h3>* " +
          escapeHtml(group.name) +
          "</h3>" +
          '<button type="button" class="dcc-copy" data-dcc-copy="' +
          escapeAttr(group.items.map(function (item) {
            return item.prompt;
          }).join("\n")) +
          '">Копировать группу</button>' +
          "</div>" +
          items +
          "</section>"
        );
      })
      .join("");
  }

  document.querySelectorAll("[data-dcc-tool]").forEach(function (tool) {
    var form = tool.querySelector("[data-dcc-form]");
    var groupsWrap = tool.querySelector("[data-dcc-groups]");
    var resultsEl = tool.querySelector("[data-dcc-results]");
    var noticeEl = tool.querySelector("[data-dcc-notice]");
    var remainingEl = tool.querySelector("[data-dcc-remaining]");
    var costEl = tool.querySelector("[data-dcc-cost]");
    var addGroupButton = tool.querySelector("[data-dcc-add-group]");
    var customPaletteField = tool.querySelector("[data-dcc-custom-palette]");
    var paletteVariants = tool.querySelector("[data-dcc-palette-variants]");
    var paletteNote = tool.querySelector("[data-dcc-palette-note]");
    var imageSlots = tool.querySelectorAll("[data-dcc-image-slot]");

    function setNotice(message, kind) {
      noticeEl.hidden = !message;
      noticeEl.textContent = message || "";
      noticeEl.className = "dcc-notice";

      if (kind) {
        noticeEl.classList.add("is-" + kind);
      }
    }

    function updateCostPreview() {
      var creditsPerItem = Number(DCC_TOOL.creditsPerItem || 1);
      var countInputs = form.querySelectorAll('input[name="group_count[]"]');
      var total = 0;

      countInputs.forEach(function (input) {
        total += Math.max(1, Number(input.value || 1));
      });

      costEl.textContent = String(total * creditsPerItem);
    }

    function setVisibility(element, visible, displayValue) {
      if (!element) {
        return;
      }
      element.hidden = !visible;
      element.style.display = visible ? displayValue : "none";
    }

    function updatePaletteState() {
      var selected = form.querySelector('input[name="palette_mode"]:checked');
      if (!customPaletteField || !paletteVariants || !paletteNote) {
        return;
      }

      setVisibility(customPaletteField, false, "grid");
      setVisibility(paletteVariants, false, "grid");
      setVisibility(paletteNote, false, "block");

      if (!selected) {
        setVisibility(paletteVariants, true, "grid");
        return;
      }

      if (selected.value === "custom") {
        setVisibility(customPaletteField, true, "grid");
        return;
      }

      if (selected.value === "match_images") {
        setVisibility(paletteNote, true, "block");
        paletteNote.textContent = "Цвета будут ориентироваться на загруженные референсы.";
        return;
      }

      if (selected.value === "auto") {
        setVisibility(paletteNote, true, "block");
        paletteNote.textContent = "Нейросеть сама выберет цветовую гамму.";
        return;
      }

      setVisibility(paletteVariants, true, "grid");
    }

    function addGroupRow(name, count) {
      if (groupsWrap.querySelectorAll("[data-dcc-group]").length >= Number(DCC_TOOL.maxGroups || 8)) {
        setNotice("Достигнут лимит групп для этого набора.", "error");
        return;
      }

      var row = document.createElement("div");
      row.className = "dcc-group-row";
      row.setAttribute("data-dcc-group", "");
      row.innerHTML =
        '<input type="text" name="group_name[]" value="' +
        escapeHtml(name || "") +
        '" placeholder="например: животные" />' +
        '<input type="number" min="1" max="' +
        Number(DCC_TOOL.maxItemsPerGroup || 12) +
        '" name="group_count[]" value="' +
        Number(count || 1) +
        '" />' +
        '<button type="button" class="dcc-icon-button" data-dcc-remove-group aria-label="Удалить группу">x</button>';

      groupsWrap.appendChild(row);
      attachRowEvents(row);
      updateCostPreview();
    }

    function updateImageSlot(slot) {
      var input = slot.querySelector('input[type="file"]');
      var text = slot.querySelector(".dcc-image-slot__text");
      var inner = slot.querySelector(".dcc-image-slot__inner");
      if (!input || !text) {
        return;
      }

      if (input.files && input.files.length > 0) {
        if (input.files[0].type && !input.files[0].type.startsWith("image/")) {
          setNotice("Можно загружать только изображения.", "error");
          input.value = "";
          return;
        }

        slot.classList.add("is-filled");
        text.textContent = input.files[0].name;
        var reader = new FileReader();
        reader.onload = function (event) {
          if (!inner) {
            return;
          }
          inner.innerHTML =
            '<img class="dcc-image-slot__preview" alt="" src="' +
            escapeAttr(event.target && event.target.result ? event.target.result : "") +
            '" />';
        };
        reader.readAsDataURL(input.files[0]);
      } else {
        slot.classList.remove("is-filled");
        if (inner) {
          inner.innerHTML =
            '<span class="dcc-image-slot__plus">+</span><span class="dcc-image-slot__text">Нажмите или перетащите</span>';
        }
      }
    }

    function attachRowEvents(row) {
      var removeButton = row.querySelector("[data-dcc-remove-group]");
      var countInput = row.querySelector('input[name="group_count[]"]');

      removeButton.addEventListener("click", function () {
        var rows = groupsWrap.querySelectorAll("[data-dcc-group]");
        if (rows.length <= 1) {
          setNotice("Оставьте хотя бы одну группу.", "error");
          return;
        }
        row.remove();
        updateCostPreview();
      });

      countInput.addEventListener("input", updateCostPreview);
    }

    groupsWrap.querySelectorAll("[data-dcc-group]").forEach(attachRowEvents);
    updatePaletteState();
    imageSlots.forEach(function (slot) {
      var input = slot.querySelector('input[type="file"]');
      if (!input) {
        return;
      }
      input.addEventListener("change", function () {
        updateImageSlot(slot);
      });
      updateImageSlot(slot);
    });

    addGroupButton.addEventListener("click", function () {
      addGroupRow("новая группа", 3);
    });

    form.addEventListener("input", updateCostPreview);
    form.addEventListener("change", function (event) {
      if (event.target && event.target.name === "palette_mode") {
        updatePaletteState();
      }
    });
    updateCostPreview();

    form.addEventListener("submit", function (event) {
      event.preventDefault();
      setNotice("", "");
      resultsEl.innerHTML = "";

      var formData = new FormData(form);
      formData.append("action", "dcc_generate_clipart");
      formData.append("nonce", DCC_TOOL.nonce);

      fetch(DCC_TOOL.ajaxUrl, {
        method: "POST",
        credentials: "same-origin",
        body: formData,
      })
        .then(function (response) {
          return response.json();
        })
        .then(function (payload) {
          if (!payload.success) {
            throw new Error(payload.data && payload.data.message ? payload.data.message : "Запрос не выполнен.");
          }

          remainingEl.textContent = String(payload.data.remaining);
          resultsEl.innerHTML = buildResultHtml(payload.data.results);
          setNotice("Сгенерировано. Списано кредитов: " + payload.data.cost + ".", "success");
        })
        .catch(function (error) {
          setNotice(error.message || "Произошла ошибка.", "error");
        });
    });

    resultsEl.addEventListener("click", function (event) {
      var button = event.target.closest("[data-dcc-copy]");
      if (!button) {
        return;
      }

      var value = button.getAttribute("data-dcc-copy") || "";
      navigator.clipboard.writeText(value);
      button.textContent = "Скопировано";
      window.setTimeout(function () {
        button.textContent = "Копировать";
      }, 1200);
    });
  });
})();
