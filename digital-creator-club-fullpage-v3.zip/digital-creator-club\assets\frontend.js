(function () {
  function escapeHtml(text) {
    return text
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#39;");
  }

  function escapeAttr(text) {
    return escapeHtml(String(text)).replaceAll("\n", "&#10;").replaceAll("\r", "");
  }

  function buildResultHtml(results) {
    return results
      .map(function (group) {
        var items = group.items
          .map(function (item) {
            return (
              '<article class="dcc-result-item">' +
              '<div class="dcc-result-item__head">' +
              "<strong>* " +
              escapeHtml(item.title) +
              "</strong>" +
              '<button type="button" class="dcc-copy" data-dcc-copy="' +
              escapeAttr(item.prompt) +
              '">Copy</button>' +
              "</div>" +
              '<p class="dcc-result-box">' +
              escapeHtml(item.prompt) +
              "</p>" +
              "</article>"
            );
          })
          .join("");

        return (
          '<section class="dcc-result-group">' +
          '<div class="dcc-result-group__head">' +
          "<h3>* " +
          escapeHtml(group.name) +
          "</h3>" +
          '<button type="button" class="dcc-copy" data-dcc-copy="' +
          escapeAttr(group.items.map(function (item) {
            return item.prompt;
          }).join("\n")) +
          '">Copy section</button>' +
          "</div>" +
          items +
          "</section>"
        );
      })
      .join("");
  }

  document.querySelectorAll("[data-dcc-tool]").forEach(function (tool) {
    var form = tool.querySelector("[data-dcc-form]");
    var groupsWrap = tool.querySelector("[data-dcc-groups]");
    var resultsEl = tool.querySelector("[data-dcc-results]");
    var noticeEl = tool.querySelector("[data-dcc-notice]");
    var remainingEl = tool.querySelector("[data-dcc-remaining]");
    var costEl = tool.querySelector("[data-dcc-cost]");
    var addGroupButton = tool.querySelector("[data-dcc-add-group]");
    var customPaletteField = tool.querySelector("[data-dcc-custom-palette]");
    var imageSlots = tool.querySelectorAll("[data-dcc-image-slot]");

    function setNotice(message, kind) {
      noticeEl.hidden = !message;
      noticeEl.textContent = message || "";
      noticeEl.className = "dcc-notice";

      if (kind) {
        noticeEl.classList.add("is-" + kind);
      }
    }

    function updateCostPreview() {
      var creditsPerItem = Number(DCC_TOOL.creditsPerItem || 1);
      var countInputs = form.querySelectorAll('input[name="group_count[]"]');
      var total = 0;

      countInputs.forEach(function (input) {
        total += Math.max(1, Number(input.value || 1));
      });

      costEl.textContent = String(total * creditsPerItem);
    }

    function updatePaletteState() {
      var selected = form.querySelector('input[name="palette"]:checked');
      if (!customPaletteField) {
        return;
      }

      customPaletteField.hidden = !selected || selected.value !== "custom";
    }

    function addGroupRow(name, count) {
      if (groupsWrap.querySelectorAll("[data-dcc-group]").length >= Number(DCC_TOOL.maxGroups || 8)) {
        setNotice("Group limit reached for this pack.", "error");
        return;
      }

      var row = document.createElement("div");
      row.className = "dcc-group-row";
      row.setAttribute("data-dcc-group", "");
      row.innerHTML =
        '<input type="text" name="group_name[]" value="' +
        escapeHtml(name || "") +
        '" placeholder="e.g. animals" />' +
        '<input type="number" min="1" max="' +
        Number(DCC_TOOL.maxItemsPerGroup || 12) +
        '" name="group_count[]" value="' +
        Number(count || 1) +
        '" />' +
        '<button type="button" class="dcc-icon-button" data-dcc-remove-group aria-label="Remove group">x</button>';

      groupsWrap.appendChild(row);
      attachRowEvents(row);
      updateCostPreview();
    }

    function updateImageSlot(slot) {
      var input = slot.querySelector('input[type="file"]');
      var text = slot.querySelector(".dcc-image-slot__text");
      if (!input || !text) {
        return;
      }

      if (input.files && input.files.length > 0) {
        slot.classList.add("is-filled");
        text.textContent = input.files[0].name;
      } else {
        slot.classList.remove("is-filled");
        text.textContent = "Drop or tap";
      }
    }

    function attachRowEvents(row) {
      var removeButton = row.querySelector("[data-dcc-remove-group]");
      var countInput = row.querySelector('input[name="group_count[]"]');

      removeButton.addEventListener("click", function () {
        var rows = groupsWrap.querySelectorAll("[data-dcc-group]");
        if (rows.length <= 1) {
          setNotice("Keep at least one group.", "error");
          return;
        }
        row.remove();
        updateCostPreview();
      });

      countInput.addEventListener("input", updateCostPreview);
    }

    groupsWrap.querySelectorAll("[data-dcc-group]").forEach(attachRowEvents);
    updatePaletteState();
    imageSlots.forEach(function (slot) {
      var input = slot.querySelector('input[type="file"]');
      if (!input) {
        return;
      }
      input.addEventListener("change", function () {
        updateImageSlot(slot);
      });
      updateImageSlot(slot);
    });

    addGroupButton.addEventListener("click", function () {
      addGroupRow("new group", 3);
    });

    form.addEventListener("input", updateCostPreview);
    form.addEventListener("change", function (event) {
      if (event.target && event.target.name === "palette") {
        updatePaletteState();
      }
    });
    updateCostPreview();

    form.addEventListener("submit", function (event) {
      event.preventDefault();
      setNotice("", "");
      resultsEl.innerHTML = "";

      var formData = new FormData(form);
      formData.append("action", "dcc_generate_clipart");
      formData.append("nonce", DCC_TOOL.nonce);

      fetch(DCC_TOOL.ajaxUrl, {
        method: "POST",
        credentials: "same-origin",
        body: formData,
      })
        .then(function (response) {
          return response.json();
        })
        .then(function (payload) {
          if (!payload.success) {
            throw new Error(payload.data && payload.data.message ? payload.data.message : "Request failed.");
          }

          remainingEl.textContent = String(payload.data.remaining);
          resultsEl.innerHTML = buildResultHtml(payload.data.results);
          setNotice("Generated " + payload.data.cost + " credits worth of prompts.", "success");
        })
        .catch(function (error) {
          setNotice(error.message || "Something went wrong.", "error");
        });
    });

    resultsEl.addEventListener("click", function (event) {
      var button = event.target.closest("[data-dcc-copy]");
      if (!button) {
        return;
      }

      var value = button.getAttribute("data-dcc-copy") || "";
      navigator.clipboard.writeText(value);
      button.textContent = "Copied";
      window.setTimeout(function () {
        button.textContent = "Copy";
      }, 1200);
    });
  });
})();
